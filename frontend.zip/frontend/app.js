// ─── PenCap AI · app.js ───────────────────────────────────────────────────
"use strict";

// ── DOM refs ──────────────────────────────────────────────────────────────
const $ = id => document.getElementById(id);
const camImg       = $("cam-img");
const overlay      = $("canvas-overlay");
const ctx          = overlay.getContext("2d");
const placeholder  = $("placeholder");
const scanLine     = $("scan-line");
const badge        = $("detection-badge");
const statusPulse  = $("status-pulse");
const statusText   = $("status-text");
const resultCard   = $("result-card");
const resultLabel  = $("result-label");
const confBar      = $("conf-bar");
const confVal      = $("conf-val");
const bboxInfo     = $("bbox-info");
const frameCount   = $("frame-count");
const latencyEl    = $("latency");
const intervalDisp = $("interval-display");
const toast        = $("toast");

const mCapped   = $("m-capped");
const mUncapped = $("m-uncapped");
const mTotal    = $("m-total");
const mSaved    = $("m-saved");

const btnConnect = $("btn-connect");
const btnCorrect = $("btn-correct");
const btnWrong   = $("btn-wrong");
const btnSave    = $("btn-save");
const btnReset   = $("btn-reset");
const btnClearLog= $("btn-clear-log");
const threshSlider = $("conf-threshold");
const threshVal  = $("thresh-val");
const soundToggle= $("sound-toggle");

// ── State ─────────────────────────────────────────────────────────────────
let state = {
  connected: false,
  running: false,
  timer: null,
  frameNum: 0,
  lastResult: null,
  correctedClassId: null,
  saveEnabled: false,
  counts: { capped: 0, uncapped: 0, total: 0, saved: 0 },
  paused: false,    // paused while user corrects
};

const BEEP_FREQ = 880;
let audioCtx = null;
function beep() {
  try {
    if (!audioCtx) audioCtx = new (window.AudioContext || window.webkitAudioContext)();
    const osc = audioCtx.createOscillator();
    const gain = audioCtx.createGain();
    osc.connect(gain); gain.connect(audioCtx.destination);
    osc.frequency.value = BEEP_FREQ;
    osc.type = "sine";
    gain.gain.setValueAtTime(0.3, audioCtx.currentTime);
    gain.gain.exponentialRampToValueAtTime(0.001, audioCtx.currentTime + 0.35);
    osc.start(); osc.stop(audioCtx.currentTime + 0.35);
  } catch(_) {}
}

// ── Logging ───────────────────────────────────────────────────────────────
function log(msg, type = "info") {
  const list = $("log-list");
  const entry = document.createElement("div");
  entry.className = `log-entry ${type}`;
  const t = new Date().toTimeString().slice(0,8);
  entry.innerHTML = `<span class="log-time">${t}</span><span class="log-msg">${msg}</span>`;
  list.prepend(entry);
  while (list.children.length > 80) list.removeChild(list.lastChild);
}

// ── Toast ─────────────────────────────────────────────────────────────────
let toastTimer;
function showToast(msg, dur = 2500) {
  toast.textContent = msg;
  toast.classList.add("show");
  clearTimeout(toastTimer);
  toastTimer = setTimeout(() => toast.classList.remove("show"), dur);
}

// ── Status indicator ──────────────────────────────────────────────────────
function setStatus(label, mode) {
  statusText.textContent = label;
  statusPulse.className = "pulse" + (mode ? " " + mode : "");
}

// ── Canvas overlay ────────────────────────────────────────────────────────
function clearOverlay() { ctx.clearRect(0, 0, overlay.width, overlay.height); }

function drawBBox(bboxPixel, label, conf, classId) {
  if (!bboxPixel || bboxPixel.length < 4) return;
  const [x1, y1, x2, y2] = bboxPixel;
  const scaleX = overlay.width  / camImg.naturalWidth  || overlay.width  / 640;
  const scaleY = overlay.height / camImg.naturalHeight || overlay.height / 480;
  const sx1 = x1 * scaleX, sy1 = y1 * scaleY;
  const sx2 = x2 * scaleX, sy2 = y2 * scaleY;
  const color = classId === 1 ? "#10b981" : classId === 0 ? "#ef4444" : "#f59e0b";
  const glow = classId === 1 ? "#10b98199" : classId === 0 ? "#ef444499" : "#f59e0b99";

  ctx.save();
  ctx.shadowColor = glow; ctx.shadowBlur = 16;
  ctx.strokeStyle = color; ctx.lineWidth = 2.5;
  ctx.strokeRect(sx1, sy1, sx2 - sx1, sy2 - sy1);
  ctx.restore();

  // Corner accents
  const cs = 12;
  ctx.save();
  ctx.strokeStyle = color; ctx.lineWidth = 3;
  ctx.shadowColor = glow; ctx.shadowBlur = 10;
  [[sx1,sy1,1,1],[sx2,sy1,-1,1],[sx1,sy2,1,-1],[sx2,sy2,-1,-1]].forEach(([x,y,dx,dy]) => {
    ctx.beginPath(); ctx.moveTo(x+dx*cs, y); ctx.lineTo(x,y); ctx.lineTo(x, y+dy*cs); ctx.stroke();
  });
  ctx.restore();

  // Label
  const txt = `${label} ${(conf*100).toFixed(0)}%`;
  ctx.font = "bold 13px monospace";
  const tw = ctx.measureText(txt).width;
  ctx.fillStyle = color + "cc";
  ctx.fillRect(sx1 - 1, sy1 - 22, tw + 12, 20);
  ctx.fillStyle = "#fff";
  ctx.fillText(txt, sx1 + 5, sy1 - 7);
}

// ── Capture single frame from img stream ──────────────────────────────────
function captureFrame() {
  const tmpCanvas = document.createElement("canvas");
  tmpCanvas.width = camImg.naturalWidth || 640;
  tmpCanvas.height = camImg.naturalHeight || 480;
  const tc = tmpCanvas.getContext("2d");
  tc.drawImage(camImg, 0, 0);
  return tmpCanvas.toDataURL("image/jpeg", 0.82);
}

// ── Inference ─────────────────────────────────────────────────────────────
async function runInference() {
  if (state.paused || !state.running) return;
  const apiBase = $("api-url").value.trim().replace(/\/$/, "");
  const threshold = parseFloat(threshSlider.value);
  const t0 = performance.now();

  let frameData;
  try { frameData = captureFrame(); }
  catch(e) { log("Frame capture failed: " + e.message, "warn"); return; }

  state.frameNum++;
  frameCount.textContent = state.frameNum;

  try {
    const res = await fetch(`${apiBase}/predict`, {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ image: frameData, conf_threshold: threshold }),
      signal: AbortSignal.timeout(4000),
    });
    if (!res.ok) throw new Error(`HTTP ${res.status}`);
    const data = await res.json();
    const lat = Math.round(performance.now() - t0);
    latencyEl.textContent = lat;
    handleResult(data, frameData);
  } catch(e) {
    log("API error: " + e.message, "warn");
    setStatus("API Error", "error");
  }
}

// ── Handle detection result ───────────────────────────────────────────────
function handleResult(data, frameData) {
  state.lastResult = { ...data, frameData };
  state.correctedClassId = data.class_id;

  const cls = data.class_id;
  const label = data.label || "UNKNOWN";
  const conf = data.confidence || 0;
  const bboxPx = data.bbox_pixel || [];

  // Counts
  if (cls === 1) state.counts.capped++;
  else if (cls === 0) state.counts.uncapped++;
  state.counts.total++;
  updateCounters();

  // Canvas
  clearOverlay();
  if (bboxPx.length >= 4) drawBBox(bboxPx, label, conf, cls);

  // Result card
  const mode = cls === 1 ? "ok" : cls === 0 ? "bad" : "none";
  resultCard.className = `result-card ${mode}`;
  resultLabel.className = `result-label ${mode}`;
  resultLabel.textContent = cls === -1 ? "NO PEN" : label;
  confBar.style.width = (conf * 100) + "%";
  confBar.style.background = cls === 1 ? "var(--ok)" : cls === 0 ? "var(--danger)" : "var(--warn)";
  confVal.textContent = (conf * 100).toFixed(0) + "%";
  if (data.bbox && data.bbox.length >= 4) {
    const b = data.bbox;
    bboxInfo.textContent = `cx:${b[0].toFixed(3)} cy:${b[1].toFixed(3)} w:${b[2].toFixed(3)} h:${b[3].toFixed(3)}`;
  } else {
    bboxInfo.textContent = cls === -1 ? "No object in frame" : data.message || "—";
  }

  // Badge
  badge.className = "detection-badge show " + mode;
  badge.textContent = cls === -1 ? "NO PEN DETECTED" : label;
  setTimeout(() => badge.classList.remove("show"), 2000);

  // Sound
  if (cls === 0 && soundToggle.checked) {
    beep();
    document.body.classList.remove("alert-flash");
    void document.body.offsetWidth;
    document.body.classList.add("alert-flash");
  }

  log(`${label} · ${(conf*100).toFixed(1)}% · frame #${state.frameNum}${data.mock?" [mock]":""}`, mode === "ok" ? "ok" : mode === "bad" ? "bad" : "info");

  // Enable action buttons
  if (cls !== -1) {
    btnCorrect.disabled = false;
    btnWrong.disabled = false;
    btnReset.disabled = false;
    state.paused = false;
  }
}

// ── Counters ──────────────────────────────────────────────────────────────
function updateCounters() {
  mCapped.textContent = state.counts.capped;
  mUncapped.textContent = state.counts.uncapped;
  mTotal.textContent = state.counts.total;
  mSaved.textContent = state.counts.saved;
}

// ── Connect / Disconnect ──────────────────────────────────────────────────
function connect() {
  const url = $("cam-url").value.trim();
  if (!url) { showToast("Enter a webcam URL"); return; }

  camImg.onerror = () => {
    setStatus("Camera Error", "error");
    log("Cannot load stream: " + url, "warn");
  };
  camImg.onload = () => {
    placeholder.style.display = "none";
    overlay.width = camImg.offsetWidth;
    overlay.height = camImg.offsetHeight;
    setStatus("Live", "live");
    scanLine.classList.add("active");
    startInference();
    log("Connected to " + url, "info");
  };

  // MJPEG streams: append timestamp to bust cache
  camImg.src = url + (url.includes("?") ? "&" : "?") + "_t=" + Date.now();
  state.connected = true;
  btnConnect.textContent = "■ Disconnect";
  btnConnect.style.background = "linear-gradient(135deg,#374151,#1f2937)";
}

function disconnect() {
  clearInterval(state.timer);
  state.timer = null;
  state.running = false;
  state.connected = false;
  camImg.src = "";
  placeholder.style.display = "flex";
  scanLine.classList.remove("active");
  clearOverlay();
  setStatus("Idle", "");
  btnConnect.textContent = "▶ Connect";
  btnConnect.style.background = "";
  log("Disconnected", "info");
}

// ── Auto inference loop ───────────────────────────────────────────────────
function startInference() {
  const secs = parseFloat($("interval").value) || 1.5;
  intervalDisp.textContent = `Every ${secs}s`;
  state.running = true;
  clearInterval(state.timer);
  state.timer = setInterval(runInference, secs * 1000);
  // Fire immediately
  runInference();
}

// ── Button handlers ───────────────────────────────────────────────────────
btnConnect.addEventListener("click", () => {
  if (state.connected) disconnect(); else connect();
});

btnCorrect.addEventListener("click", () => {
  state.paused = true;
  btnSave.disabled = false;
  btnCorrect.disabled = true;
  showToast("Confirmed ✅ — press 💾 to save");
  log("User confirmed prediction", "info");
});

btnWrong.addEventListener("click", () => {
  if (!state.lastResult) return;
  const flipped = state.lastResult.class_id === 1 ? 0 : 1;
  state.correctedClassId = flipped;
  const label = flipped === 1 ? "CAPPED" : "UNCAPPED";
  resultLabel.textContent = label;
  resultLabel.className = "result-label " + (flipped === 1 ? "ok" : "bad");
  state.paused = true;
  btnSave.disabled = false;
  btnWrong.disabled = true;
  showToast(`Flipped to ${label} — press 💾 to save`);
  log(`User flipped label → ${label}`, "warn");
  // Redraw bbox with corrected color
  if (state.lastResult.bbox_pixel?.length >= 4) {
    clearOverlay();
    drawBBox(state.lastResult.bbox_pixel, label, state.lastResult.confidence, flipped);
  }
});

btnSave.addEventListener("click", async () => {
  if (!state.lastResult) return;
  const apiBase = $("api-url").value.trim().replace(/\/$/, "");
  btnSave.disabled = true;
  btnSave.textContent = "Saving…";
  try {
    const res = await fetch(`${apiBase}/save`, {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({
        image: state.lastResult.frameData,
        class_id: state.correctedClassId,
        bbox: state.lastResult.bbox || [],
        image_id: state.frameNum.toString(),
      }),
    });
    const data = await res.json();
    state.counts.saved++;
    updateCounters();
    showToast(`Saved as ${data.image_id} 💾`);
    log(`Saved: ${data.image_id} · class ${state.correctedClassId}`, "ok");
  } catch(e) {
    showToast("Save failed: " + e.message);
    log("Save error: " + e.message, "warn");
  }
  btnSave.textContent = "💾 Save";
  resetState();
});

btnReset.addEventListener("click", () => {
  resetState();
  clearOverlay();
  log("Reset", "info");
});

function resetState() {
  state.paused = false;
  state.lastResult = null;
  state.correctedClassId = null;
  btnCorrect.disabled = true;
  btnWrong.disabled = true;
  btnSave.disabled = true;
  btnReset.disabled = true;
  resultLabel.textContent = "AWAITING";
  resultLabel.className = "result-label idle";
  resultCard.className = "result-card";
  confBar.style.width = "0%";
  confVal.textContent = "—";
  bboxInfo.textContent = "No detection";
}

threshSlider.addEventListener("input", () => {
  threshVal.textContent = parseFloat(threshSlider.value).toFixed(2);
});

btnClearLog.addEventListener("click", () => { $("log-list").innerHTML = ""; });

// ── Resize canvas on window resize ────────────────────────────────────────
window.addEventListener("resize", () => {
  if (state.connected) {
    overlay.width = camImg.offsetWidth;
    overlay.height = camImg.offsetHeight;
  }
});

// ── PWA Install Prompt ────────────────────────────────────────────────────
let deferredInstallPrompt = null;
const btnInstall = $("btn-install");

// Always show the install button
btnInstall.style.display = "flex";

// Check if already running as installed PWA
if (window.matchMedia("(display-mode: standalone)").matches || window.navigator.standalone) {
  btnInstall.style.display = "none";
}

window.addEventListener("beforeinstallprompt", (e) => {
  e.preventDefault();
  deferredInstallPrompt = e;
  btnInstall.style.display = "flex";
  log("App is installable — click Install App", "info");
});

btnInstall.addEventListener("click", async () => {
  if (deferredInstallPrompt) {
    deferredInstallPrompt.prompt();
    const { outcome } = await deferredInstallPrompt.userChoice;
    if (outcome === "accepted") {
      log("App installed successfully! 🎉", "ok");
      showToast("App installed! Check your desktop 🎉");
    } else {
      log("Install dismissed by user", "info");
    }
    deferredInstallPrompt = null;
    btnInstall.style.display = "none";
  } else {
    // Fallback: guide user to use browser install
    showToast("Use browser menu ⋮ → 'Install app' or 'Add to Home screen'", 4000);
    log("Use browser menu → Install app (or ⋮ → Add to Home screen)", "info");
  }
});

window.addEventListener("appinstalled", () => {
  btnInstall.style.display = "none";
  deferredInstallPrompt = null;
  log("PenCap AI installed to device", "ok");
  showToast("PenCap AI installed! 🎉");
});

// ── Service Worker ────────────────────────────────────────────────────────
if ("serviceWorker" in navigator) {
  navigator.serviceWorker.register("sw.js")
    .then((reg) => {
      log("PWA service worker active", "info");
      // Force update check
      reg.update();
    })
    .catch(e => log("SW error: " + e, "warn"));
}

// ── Init ───────────────────────────────────────────────────────────────────
log("PenCap AI ready — enter webcam URL and press Connect", "info");
